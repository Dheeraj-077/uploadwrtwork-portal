-- MySQL dump 10.19  Distrib 10.3.35-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: sunahos2_uploadartwork
-- ------------------------------------------------------
-- Server version	10.3.35-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addjobtype`
--

DROP TABLE IF EXISTS `addjobtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addjobtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobtype` varchar(255) NOT NULL,
  `pricing` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addjobtype`
--

LOCK TABLES `addjobtype` WRITE;
/*!40000 ALTER TABLE `addjobtype` DISABLE KEYS */;
INSERT INTO `addjobtype` (`id`, `jobtype`, `pricing`) VALUES (4,'Vector Art- Simple',5),(5,'Digitizing, Price per thousand',1),(6,'Logo Design (2 options)',50),(7,'Email Blast (3 versions) 1-Option)',45),(8,'Branding Packages: Logo redesign, web banners, & Business card layout',130),(9,'Vector Art- Standard',20),(10,'Vector Art- Complex',40),(11,'Vector Art- Challenging',80),(12,'Vector Art- Speciality',100);
/*!40000 ALTER TABLE `addjobtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `uploaded_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobid_fk` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` (`id`, `client_id`, `job_id`, `file_name`, `file_size`, `file_type`, `uploaded_on`) VALUES (78,9,47,'01706418.png','6140','image/png','2022-04-01 10:04:19'),(79,9,48,'08669-UrbNvyHt-1-NF0A3LHBUrbNvyHtModelFront2-1200W.jpg','336795','image/jpeg','2022-04-06 08:08:49'),(80,9,48,'18669-TNFLtGreyHe-1-NF0A3LHBTNFLightGreyHthrModelFront-1200W.jpg','665613','image/jpeg','2022-04-06 08:08:49'),(81,9,48,'28669-TNFBlack-1-NF0A3LHBTNFBlackModelFront-1200W.jpg','580342','image/jpeg','2022-04-06 08:08:49'),(82,9,48,'38669-OrngOchre-1-NF0A3LHBOrngOchreModelFront-1200W.jpg','227824','image/jpeg','2022-04-06 08:08:49'),(83,9,48,'48669-MonsterBlue-1-NF0A3LHBMonsterBlueModelFront-1200W.jpg','755814','image/jpeg','2022-04-06 08:08:49'),(84,9,49,'0IMG-20201013-WA0099.jpg','93991','image/jpeg','2022-05-10 09:29:03'),(85,9,49,'1insrc logo png.png','703303','image/png','2022-05-10 09:29:03');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `po_no` varchar(255) NOT NULL,
  `job_type` varchar(255) NOT NULL,
  `revise` varchar(255) NOT NULL,
  `timeline` varchar(255) NOT NULL,
  `format` varchar(255) NOT NULL,
  `job_description` text NOT NULL,
  `deadline` date NOT NULL,
  `uploaded_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` (`id`, `client_id`, `job_title`, `po_no`, `job_type`, `revise`, `timeline`, `format`, `job_description`, `deadline`, `uploaded_on`) VALUES (47,9,'Test','VA101','Digitizing, Price per thousand','Revision','Standard','Vector PDF,CS6 EPS,CS5 EPS,JPG,PNG,','Testing','2022-04-08','2022-04-01 10:04:19'),(48,9,'Test2','','Digitizing, Price per thousand','New','Standard','','This is testing','2022-04-09','2022-04-06 08:08:49'),(49,9,'Test5','vjhsj','Branding Packages: Logo redesign, web banners, & Business card layout','Revision','Standard','Vector PDF,CS6 EPS,CS5 EPS,CS4 EPS,','Raster to vector','2022-05-12','2022-05-10 09:29:03');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `managerfiles`
--

DROP TABLE IF EXISTS `managerfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `managerfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `jobstatus` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `managerfiles`
--

LOCK TABLES `managerfiles` WRITE;
/*!40000 ALTER TABLE `managerfiles` DISABLE KEYS */;
INSERT INTO `managerfiles` (`id`, `job_id`, `jobstatus`, `file_name`, `uploaded_on`) VALUES (72,48,'completed','48_47_01706418.png','2022-04-07 21:17:53'),(73,48,'completed','48_AppSmart-Logo-RGB.png','2022-04-07 21:28:11');
/*!40000 ALTER TABLE `managerfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pass_reset`
--

DROP TABLE IF EXISTS `pass_reset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pass_reset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pass_reset`
--

LOCK TABLES `pass_reset` WRITE;
/*!40000 ALTER TABLE `pass_reset` DISABLE KEYS */;
INSERT INTO `pass_reset` (`id`, `email`, `token`) VALUES (16,'dheeraj@vartservices.com','45fac9cc20b5ac1ccc6c84d872ca8dc185186203b465f796d5512d956ace19627af338c25ff8016a1585d3c8673b688366c1');
/*!40000 ALTER TABLE `pass_reset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(255) DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusers`
--

LOCK TABLES `tblusers` WRITE;
/*!40000 ALTER TABLE `tblusers` DISABLE KEYS */;
INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `MobileNumber`, `Password`, `role`, `RegDate`) VALUES (4,'Thelma','thelma.k@vartservices.com',1234567895,'Thelma@123','admin','2022-01-28 09:18:09'),(5,'rahath','rahath@vartservices.com',1234567892,'Rahath123','manager','2022-03-21 11:15:33'),(9,'Dheeraj','dheeraj@vartservices.com',1234567892,'Dh33r@j123','client','2022-03-28 13:10:49'),(10,'Thelma Kadambatta','vartservicespvtltd@gmail.com',8097108820,'Thelma@123','manager','2022-03-30 13:35:51'),(11,'admin','admin@gmail.com',1234567895,'Admin@123','admin','2022-04-01 07:32:52'),(12,'rock','dheeraj.vartservices@gmail.com',1234567895,'Dh33r@j123','client','2022-04-05 09:06:55');
/*!40000 ALTER TABLE `tblusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sunahos2_uploadartwork'
--

--
-- Dumping routines for database 'sunahos2_uploadartwork'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-16 14:36:40
